# usage
```
./run.sh 500 jump jumpp
```