# SampleHalfEdge
这是半边结构的简化版本，方便大家入门使用

之后会上传 MeshLib 库 以及通过 MeshLib 库之上的一些算法
大家敬请期待吧
